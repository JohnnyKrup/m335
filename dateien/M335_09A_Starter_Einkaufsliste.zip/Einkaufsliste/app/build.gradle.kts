plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "ch.wiss.m335.einkauf"
    compileSdk {
        version = release(36) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "ch.wiss.m335.einkauf"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
    implementation(libs.constraintlayout)
    implementation(libs.material)

    // Room, die Datenbank. Zwei Zeilen, und beide sind nötig.
    // room-runtime ist die Bibliothek, die zur Laufzeit arbeitet.
    // room-compiler erzeugt beim Bauen den Code hinter deinem Dao.
    //
    // annotationProcessor und nicht ksp. KSP gilt nur für Kotlin,
    // wir arbeiten mit Java. Das ist eine der häufigsten KI-Fallen.
    implementation(libs.room.runtime)
    annotationProcessor(libs.room.compiler)

    testImplementation(libs.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)
}
