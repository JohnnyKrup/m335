package ch.wiss.m335.einkauf;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Die Startseite. Hier soll die Liste aller Einträge erscheinen.
 *
 * Die Activity ist absichtlich leer. Was du daraus machst, ist die
 * Aufgabe. Das Gerüst darum herum ist bereits fertig und wird nicht
 * bewertet.
 */
public class MainActivity extends AppCompatActivity {

    /**
     * Log-Tag für das ganze Modul 335.
     *
     * Bewusst nicht "M335". Diese Zeichenfolge steckt auch im
     * Paketnamen ch.wiss.m335.einkauf. Das Suchfeld im Logcat sucht im
     * Freitext über alle Spalten, und damit träfe "M335" jede Zeile
     * deiner App statt nur die selbst geschriebenen.
     */
    private static final String TAG = "Modul335";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Der Rand für Statusleiste und Navigationsleiste. Ohne diesen
        // Block liegt dein oberstes Element unter der Uhr. Das Gerüst
        // ist fertig, du musst es nicht anfassen.
        final int extraPadding = Math.round(16 * getResources().getDisplayMetrics().density);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clMain), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(
                    systemBars.left + extraPadding,
                    systemBars.top + extraPadding,
                    systemBars.right + extraPadding,
                    systemBars.bottom + extraPadding);
            return insets;
        });

        Log.d(TAG, "MainActivity onCreate");

        // Ab hier ist es deine Aufgabe.
    }
}
