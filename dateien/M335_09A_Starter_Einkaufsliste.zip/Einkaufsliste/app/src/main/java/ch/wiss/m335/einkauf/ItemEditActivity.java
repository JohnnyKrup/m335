package ch.wiss.m335.einkauf;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Das Formular für einen einzelnen Eintrag.
 *
 * Die Activity ist absichtlich leer. Sie steht bereits im Manifest,
 * du kannst sie also sofort mit einem Intent öffnen.
 *
 * In Auftrag 09A bleibt sie leer. Sie steht hier, damit dein Projekt
 * genau gleich aussieht wie das Starter-Projekt am Prüfungstag.
 */
public class ItemEditActivity extends AppCompatActivity {

    /** Log-Tag für das ganze Modul 335. */
    private static final String TAG = "Modul335";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_edit);

        final int extraPadding = Math.round(16 * getResources().getDisplayMetrics().density);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clItemEdit), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(
                    systemBars.left + extraPadding,
                    systemBars.top + extraPadding,
                    systemBars.right + extraPadding,
                    systemBars.bottom + extraPadding);
            return insets;
        });

        Log.d(TAG, "ItemEditActivity onCreate");

        // Ab hier ist es deine Aufgabe.
    }
}
